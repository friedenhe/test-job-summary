#!/usr/bin/env python

# =============================================================================
# Imports
# =============================================================================
import os
import argparse
import numpy as np
from mpi4py import MPI
import openmdao.api as om
from mphys.multipoint import Multipoint
from dafoam.mphys import DAFoamBuilder, OptFuncs, DAFoamLinearConstraint, DAFoamVSPVolume
from tacs.mphys import TacsBuilder
from funtofem.mphys import MeldBuilder
from mphys.scenario_aerostructural import ScenarioAeroStructural
from pygeo.mphys import OM_DVGEOCOMP
from tacs import elements, constitutive, functions

parser = argparse.ArgumentParser()
parser.add_argument("-optimizer", help="optimizer to use", type=str, default="SNOPT")
parser.add_argument("-task", help="type of run to do", type=str, default="run_model")
parser.add_argument("-struct_material", help="type of structural material", type=str, default="aluminum")
parser.add_argument(
    "-struct_panel_thickness", help="thickness of structural shells/panels in meters", type=float, default=0.01
)
parser.add_argument(
    "-lift_constraint",
    help="lift constraint for drag objective",
    type=float,
    default=0.5,
)
parser.add_argument("-struct_safety_factor", help="safety factor for structures", type=float, default=1.5)
parser.add_argument("-angle_of_attack", help="angle of attack", type=float, default=3.0)
parser.add_argument("-mach_number", help="mach number", type=float, default=0.2)
parser.add_argument("-solver_name", help="Resolved solver name passed by the calling skill.", type=str, required=True)
parser.add_argument("-reynolds_number", help="Reynolds number", type=float, default=5e6)
parser.add_argument("-max_opt_iters", help="Maximum optimization iterations", type=int, default=50)
parser.add_argument("-max_adj_iters", help="The max GMRES iterations for the adjoint solve", type=int, default=1000)
parser.add_argument("-pc_fill_level", help="The ILU fill level for the adjoint preconditioner", type=int, default=1)
parser.add_argument("-primal_min_iters", help="Minimum number of primal iterations", type=int, default=200)
parser.add_argument(
    "-primal_func_std_tol",
    help="Primal function standard deviation tolerance",
    type=float,
    default=1e-4,
)
parser.add_argument(
    "-primal_func_slope_tol",
    help="Primal function slope tolerance",
    type=float,
    default=1e-6,
)
parser.add_argument(
    "-nlbgs_rel_tol", help="Relative tolerance for the aerostructural NLBGS solver", type=float, default=1e-7
)
parser.add_argument(
    "-nlbgs_abs_tol", help="Absolute tolerance for the aerostructural NLBGS solver", type=float, default=2.0
)
parser.add_argument(
    "-reference_area",
    help="Reference area for normalizing the drag and lift",
    type=float,
    default=None,
)
parser.add_argument(
    "-reference_length",
    help="Reference length for normalizing the moment",
    type=float,
    default=None,
)
parser.add_argument(
    "-n_cst_coeffs",
    help="The number of CST coefficients. 6 means we have 6 coefficients for the upper surface and 6 coefficients for the lower surface",
    type=int,
    default=6,
)
parser.add_argument(
    "-cst_coeffs",
    help="The CST coefficients for sectional airfoil along the span, starting from the root section",
    type=float,
    nargs="+",
    default=None,
)
parser.add_argument(
    "-chords",
    help="airfoil chords for each spanwise section",
    nargs="+",
    type=float,
    default=[1.0, 1.0],
)
parser.add_argument(
    "-spans",
    help="span lengths for each wing segment",
    nargs="+",
    type=float,
    default=[3.0],
)
parser.add_argument(
    "-sweeps",
    help="leading-edge sweep angles in degrees for each wing segment",
    nargs="+",
    type=float,
    default=[0.0],
)
parser.add_argument(
    "-dihedrals",
    help="dihedral angles in degrees for each wing segment",
    nargs="+",
    type=float,
    default=[0.0],
)
parser.add_argument(
    "-twists",
    help="twist angles in degrees for each non-root section",
    nargs="+",
    type=float,
    default=[0.0],
)
parser.add_argument(
    "-le_radius_constraint", help="LE radius constraint lower bound (-1 to disable)", type=float, default=1.0
)
parser.add_argument(
    "-thickness_constraint", help="Thickness constraint lower bound (-1 to disable)", type=float, default=0.5
)
parser.add_argument("-volume_constraint", help="Volume constraint lower bound (-1 to disable)", type=float, default=1.0)
args = parser.parse_args()

# =============================================================================
# Input Parameters
# =============================================================================

# Clean up previous run results
if MPI.COMM_WORLD.rank == 0:
    os.system("rm -rf postProcessing")
    os.system("rm -rf processor* 0.00* ")
    os.system("rm -rf *.bin *.info *.jpeg *.png reports *.hst")
    os.system("rm -rf {1..9}*")

T0 = 300.0
nuTilda0 = 4.5e-5

A0 = args.reference_area
L0 = args.reference_length
R = 287.0
k = 1.4
C = float(np.sqrt(k * R * T0))
U0 = args.mach_number * C
aoa0 = args.angle_of_attack
Ux = float(U0 * np.cos(np.radians(aoa0)))
Uz = float(U0 * np.sin(np.radians(aoa0)))

solverName = args.solver_name
if solverName == "DASimpleFoam":
    transonicPC = 0
    p0 = 0.0
    rho0 = 1.0
    p_norm = U0 * U0 / 2.0
    IC = {"U": [Ux, 0.0, Uz], "p": p0}
elif solverName == "DARhoSimpleFoam":
    transonicPC = 0
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    IC = {"U": [Ux, 0.0, Uz], "p": p0, "T": T0}
elif solverName == "DARhoSimpleCFoam":
    transonicPC = 1
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    IC = {"U": [Ux, 0.0, Uz], "p": p0, "T": T0}
elif solverName == "DAHisaFoam":
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    transonicPC = 1  # this is actually not used in hisa
    IC = {"U": [Ux, 0.0, Uz], "p": p0, "T": T0}
else:
    raise ValueError(f"Unsupported solverName `{solverName}`")

nu = U0 * L0 / args.reynolds_number
mu = nu * rho0

n_sections = len(args.chords)
time_op = "average" if args.task == "run_model" else "final"

if solverName == "DAHisaFoam":
    BC = {
        "charFarFieldBC": [Ux, 0.0, Uz, p0, T0],
        "thermo:mu": mu,
        "useWallFunction": False,
    }
elif solverName == "DASimpleFoam":
    BC = {
        "U0": {"variable": "U", "patches": ["inout"], "value": [Ux, 0.0, Uz]},
        "p0": {"variable": "p", "patches": ["inout"], "value": [p0]},
        "nuTilda0": {"variable": "nuTilda", "patches": ["inout"], "value": [nuTilda0]},
        "transport:nu": nu,
        "useWallFunction": True,
    }
else:
    BC = {
        "U0": {"variable": "U", "patches": ["inout"], "value": [Ux, 0.0, Uz]},
        "p0": {"variable": "p", "patches": ["inout"], "value": [p0]},
        "T0": {"variable": "T", "patches": ["inout"], "value": [T0]},
        "nuTilda0": {"variable": "nuTilda", "patches": ["inout"], "value": [nuTilda0]},
        "thermo:mu": mu,
        "useWallFunction": True,
    }

# Input parameters for DAFoam
daOptions = {
    "designSurfaces": ["wing"],
    "solverName": solverName,
    "transonicPCOption": transonicPC,
    "primalMinResTol": 1.0e-7,
    "primalMinResTolDiff": 1e3,
    "primalFuncStdTol": {
        "stdTol": args.primal_func_std_tol,
        "slopeTol": args.primal_func_slope_tol,
        "funcNames": ["CD", "CL"],
        "nStepsFrac": 0.5,
    },
    "primalMinIters": args.primal_min_iters,
    "printInterval": 10,
    "primalInitCondition": IC,
    "primalBC": BC,
    "function": {
        "CD": {
            "type": "force",
            "source": "patchToFace",
            "patches": ["wing"],
            "directionMode": "parallelToFlow",
            "patchVelocityInputName": "patchV",
            "scale": 1.0 / (0.5 * U0 * U0 * A0 * rho0),
            "timeOp": time_op,
            "nStepsFrac": 0.2,
        },
        "CL": {
            "type": "force",
            "source": "patchToFace",
            "patches": ["wing"],
            "directionMode": "normalToFlow",
            "patchVelocityInputName": "patchV",
            "scale": 1.0 / (0.5 * U0 * U0 * A0 * rho0),
            "timeOp": time_op,
            "nStepsFrac": 0.2,
        },
        "CM": {
            "type": "moment",
            "source": "patchToFace",
            "patches": ["wing"],
            "axis": [0.0, 1.0, 0.0],
            "center": [0.25, 0.0, 0.0],
            "scale": 1.0 / (0.5 * U0 * U0 * A0 * rho0 * L0),
            "timeOp": time_op,
            "nStepsFrac": 0.2,
        },
    },
    "adjStateOrdering": "cell",
    "adjEqnOption": {
        "gmresRelTol": 1.0e-2,  # set relative tolerance for block Gauss-Seidel adjoint
        "pcFillLevel": args.pc_fill_level,
        "jacMatReOrdering": "natural",
        "gmresMaxIters": args.max_adj_iters,
        "gmresRestart": args.max_adj_iters,
        "useNonZeroInitGuess": True,
        "dynAdjustTol": True,
    },
    "normalizeStates": {
        "U": U0,
        "p": p_norm,
        "T": T0,
        "nuTilda": nuTilda0 * 10.0,
        "phi": 1.0,
    },
    "inputInfo": {
        "aero_vol_coords": {"type": "volCoord", "components": ["solver", "function"]},
        "patchV": {
            "type": "patchVelocity",
            "patches": ["inout"],
            "flowAxis": "x",
            "normalAxis": "z",
            "components": ["solver", "function"],
        },
    },
    "outputInfo": {
        "f_aero": {
            "type": "forceCouplingOutput",
            "patches": ["wing"],
            "components": ["forceCoupling"],
            "pRef": p0,
        },
    },
    "checkMeshThreshold": {
        "maxNonOrth": 80.0,
        "maxSkewness": 10.0,
        "maxAspectRatio": 10000.0,
    },
}

# Mesh deformation setup
meshOptions = {
    "gridFile": os.getcwd(),
    "fileType": "OpenFOAM",
    # point and normal for the symmetry plane
    "symmetryPlanes": [
        [[0.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
    ],
}

if args.struct_material == "aluminum":
    struct_rho = 2780.0  # density, kg/m^3
    struct_E = 73.1e9  # elastic modulus, Pa
    struct_nu = 0.33  # poisson's ratio
    struct_kcorr = 5.0 / 6.0  # shear correction factor
    struct_ys = 324.0e6  # yield stress, Pa
else:
    print("struct_material arg not supported!")
    exit(1)


t0 = args.struct_panel_thickness  # m
tMin = 0.002  # m
tMax = 0.05  # m
gravity = 9.81


def element_callback(dvNum, compID, compDescript, elemDescripts, specialDVs, **kwargs):
    # Setup (isotropic) property and constitutive objects
    prop = constitutive.MaterialProperties(rho=struct_rho, E=struct_E, nu=struct_nu, ys=struct_ys)
    # Set one thickness dv for every component
    con = constitutive.IsoShellConstitutive(prop, t=t0, tNum=dvNum, tlb=tMin, tub=tMax)

    # For each element type in this component,
    # pass back the appropriate tacs element object
    transform = None
    elem = elements.Quad4Shell(transform, con)

    return elem


def problem_setup(scenario_name, fea_assembler, problem):
    """
    Helper function to add fixed forces and eval functions
    to structural problems used in tacs builder
    """
    # Add TACS Functions
    # Only include mass from elements that belong to pytacs components (i.e. skip concentrated masses)
    problem.addFunction("mass", functions.StructuralMass)
    problem.addFunction("ks_vmfailure", functions.KSFailure, safetyFactor=args.struct_safety_factor, ksWeight=50.0)

    # Add gravity load
    g = np.array([0.0, -gravity, 0.0])  # m/s^2
    problem.addInertialLoad(g)


# TACS Setup
tacsOptions = {
    "element_callback": element_callback,
    "problem_setup": problem_setup,
    "mesh_file": "./wingbox.bdf",
}


# Top class to setup the optimization problem
class Top(Multipoint):
    def setup(self):

        # create the builder to initialize the DASolvers
        aero_builder = DAFoamBuilder(daOptions, meshOptions, scenario="aerostructural")
        aero_builder.initialize(self.comm)

        # add the aerodynamic mesh component
        self.add_subsystem("mesh_aero", aero_builder.get_mesh_coordinate_subsystem())

        # create the builder to initialize TACS
        struct_builder = TacsBuilder(tacsOptions)
        struct_builder.initialize(self.comm)

        # add the structure mesh component
        self.add_subsystem("mesh_struct", struct_builder.get_mesh_coordinate_subsystem())

        # load and displacement transfer builder (meld), isym sets the symmetry plan axis (j)
        xfer_builder = MeldBuilder(aero_builder, struct_builder, isym=1, check_partials=True)
        xfer_builder.initialize(self.comm)

        # add the design variable component to keep the top level design variables
        dvs = self.add_subsystem("dvs", om.IndepVarComp(), promotes=["*"])

        # Keep the aero-struct geometry parameterization on the same VSP model used by the aero path.
        self.add_subsystem("geometry", OM_DVGEOCOMP(file="wing.vsp3", type="vsp"), promotes=["*"])

        # Use the CLI tolerances so the skill can control NLBGS convergence settings per case.
        # primal and adjoint solution options, i.e., nonlinear block Gauss-Seidel for aerostructural analysis
        # and linear block Gauss-Seidel for the coupled adjoint
        nonlinear_solver = om.NonlinearBlockGS(
            maxiter=10,
            iprint=2,
            use_aitken=True,
            rtol=args.nlbgs_rel_tol,
            atol=args.nlbgs_abs_tol,
        )
        linear_solver = om.LinearBlockGS(maxiter=5, iprint=2, use_aitken=True, rtol=1e-4, atol=1e-5)
        # add the coupling aerostructural scenario
        self.mphys_add_scenario(
            "scenario1",
            ScenarioAeroStructural(
                aero_builder=aero_builder, struct_builder=struct_builder, ldxfer_builder=xfer_builder
            ),
            nonlinear_solver,
            linear_solver,
        )

        # need to manually connect the vars in the geo component to scenario1
        self.connect("x_aero0", "scenario1.x_aero0")
        self.connect("x_struct0", "scenario1.x_struct0")

        # add the structural thickness DVs
        ndv_struct = struct_builder.get_ndv()
        dvs.add_output("dv_struct", np.array(ndv_struct * [t0]))
        self.connect("dv_struct", "scenario1.dv_struct")

        # more manual connection
        self.connect("mesh_aero.x_aero0", "x_aero_in")
        self.connect("mesh_struct.x_struct0", "x_struct_in")

        # thickness constraint
        varA = []
        varB = []
        for i in range(n_sections):
            for j in range(args.n_cst_coeffs):
                varA.append(f"Wing:UpperCoeff_{i}:Au_{j}")
                varB.append(f"Wing:LowerCoeff_{i}:Al_{j}")
        self.add_subsystem(
            "thickness",
            DAFoamLinearConstraint(varA=varA, coeffA=1.0, varB=varB, coeffB=-1.0, size=1, output_name="thickness_val"),
            promotes=["*"],
        )

        # LE C1 continuity constraint
        varA = []
        varB = []
        for i in range(n_sections):
            varA.append(f"Wing:UpperCoeff_{i}:Au_0")
            varB.append(f"Wing:LowerCoeff_{i}:Al_0")
        self.add_subsystem(
            "le_c1",
            DAFoamLinearConstraint(varA=varA, coeffA=1.0, varB=varB, coeffB=1.0, size=1, output_name="le_c1_val"),
            promotes=["*"],
        )

        # add volume constraint
        vsp_vars = []
        for i in range(n_sections):
            for j in range(args.n_cst_coeffs):
                vsp_vars.append(f"Wing:UpperCoeff_{i}:Au_{j}")
                vsp_vars.append(f"Wing:LowerCoeff_{i}:Al_{j}")
        for i in range(1, n_sections):
            vsp_vars.append(f"Wing:XSec_{i}:Twist")
            vsp_vars.append(f"Wing:XSec_{i}:Span")
            vsp_vars.append(f"Wing:XSec_{i}:Sweep")
            vsp_vars.append(f"Wing:XSec_{i}:Dihedral")
            vsp_vars.append(f"Wing:XSec_{i}:Tip_Chord")
        vsp_vars.append("Wing:XSec_1:Root_Chord")
        self.add_subsystem(
            "volume",
            DAFoamVSPVolume(
                vsp_file="wing.vsp3",
                vsp_vars=vsp_vars,
                slice_dir="y",
                n_slices=10,
                output_name="volume_val",
                step=1e-5,
                relativeStep=False,
            ),
            promotes=["*"],
        )

    def configure(self):

        # call this to configure the coupling solver
        super().configure()

        # get the surface coordinates from the mesh component
        points = self.mesh_aero.mphys_get_surface_mesh()

        # add pointset for both aero and struct
        self.geometry.nom_add_discipline_coords("aero", points)
        self.geometry.nom_add_discipline_coords("struct")

        # add sectional airfoil shape var
        CST = args.cst_coeffs
        for i in range(n_sections):
            for j in range(args.n_cst_coeffs):
                self.geometry.nom_addVSPVariable("Wing", f"UpperCoeff_{i}", f"Au_{j}", scaledStep=False, dh=1e-5)
                self.geometry.nom_addVSPVariable("Wing", f"LowerCoeff_{i}", f"Al_{j}", scaledStep=False, dh=1e-5)
                self.dvs.add_output(f"Wing:UpperCoeff_{i}:Au_{j}", val=CST[2 * i * args.n_cst_coeffs + j])
                self.dvs.add_output(f"Wing:LowerCoeff_{i}:Al_{j}", val=CST[(2 * i + 1) * args.n_cst_coeffs + j])
                self.add_design_var(f"Wing:UpperCoeff_{i}:Au_{j}", lower=-1.0, upper=1.0, scaler=10.0)
                self.add_design_var(f"Wing:LowerCoeff_{i}:Al_{j}", lower=-1.0, upper=1.0, scaler=10.0)

        # add sectional twist var
        for i in range(1, n_sections):
            self.geometry.nom_addVSPVariable("Wing", f"XSec_{i}", "Twist", scaledStep=False, dh=1e-5)
            self.dvs.add_output(f"Wing:XSec_{i}:Twist", val=args.twists[i - 1])
            self.add_design_var(f"Wing:XSec_{i}:Twist", lower=-1.0, upper=1.0, scaler=0.1)

        # add sectional span var
        for i in range(1, n_sections):
            self.geometry.nom_addVSPVariable("Wing", f"XSec_{i}", "Span", scaledStep=False, dh=1e-5)
            self.dvs.add_output(f"Wing:XSec_{i}:Span", val=args.spans[i - 1])
            self.add_design_var(f"Wing:XSec_{i}:Span", lower=-1.0, upper=1.0, scaler=0.1)

        # add sectional sweep var
        for i in range(1, n_sections):
            self.geometry.nom_addVSPVariable("Wing", f"XSec_{i}", "Sweep", scaledStep=False, dh=1e-5)
            self.dvs.add_output(f"Wing:XSec_{i}:Sweep", val=args.sweeps[i - 1])
            self.add_design_var(f"Wing:XSec_{i}:Sweep", lower=-1.0, upper=1.0, scaler=0.1)

        # add sectional dihedral var
        for i in range(1, n_sections):
            self.geometry.nom_addVSPVariable("Wing", f"XSec_{i}", "Dihedral", scaledStep=False, dh=1e-5)
            self.dvs.add_output(f"Wing:XSec_{i}:Dihedral", val=args.dihedrals[i - 1])
            self.add_design_var(f"Wing:XSec_{i}:Dihedral", lower=-1.0, upper=1.0, scaler=0.1)

        # add sectional chord var
        self.geometry.nom_addVSPVariable("Wing", "XSec_1", "Root_Chord", scaledStep=False, dh=1e-5)
        self.dvs.add_output("Wing:XSec_1:Root_Chord", val=args.chords[0])
        self.add_design_var("Wing:XSec_1:Root_Chord", lower=-1.0, upper=1.0, scaler=1.0)
        for i in range(1, n_sections):
            self.geometry.nom_addVSPVariable("Wing", f"XSec_{i}", "Tip_Chord", scaledStep=False, dh=1e-5)
            self.dvs.add_output(f"Wing:XSec_{i}:Tip_Chord", val=args.chords[i])
            self.add_design_var(f"Wing:XSec_{i}:Tip_Chord", lower=-1.0, upper=1.0, scaler=1.0)

        self.dvs.add_output("patchV", val=np.array([U0, aoa0]))
        self.connect("patchV", "scenario1.patchV")
        self.add_design_var("patchV", lower=[U0, 0.0], upper=[U0, 10.0], scaler=0.1)

        # add objective and constraints to the top level
        self.add_objective("scenario1.aero_post.CD", scaler=10.0)
        self.add_constraint("scenario1.aero_post.CL", equals=args.lift_constraint, scaler=1.0)
        self.add_constraint("scenario1.ks_vmfailure", lower=0.0, upper=1.0, scaler=1.0)

        # volume constraint
        if args.volume_constraint > 0:
            self.add_constraint("volume_val", lower=args.volume_constraint, scaler=1.0)

        # thickness constraint
        if args.thickness_constraint >= 0:
            for i in range(n_sections):
                for j in range(1, args.n_cst_coeffs):
                    indexI = i * args.n_cst_coeffs + j
                    cst_upper = CST[2 * i * args.n_cst_coeffs + j]
                    cst_lower = CST[(2 * i + 1) * args.n_cst_coeffs + j]
                    self.add_constraint(
                        f"thickness_val_{indexI}",
                        lower=args.thickness_constraint * (cst_upper - cst_lower),
                        scaler=1.0,
                        linear=True,
                    )
        # LE radius constraint
        if args.le_radius_constraint > 0:
            for i in range(n_sections):
                indexI = i * args.n_cst_coeffs
                cst_upper = CST[2 * i * args.n_cst_coeffs]
                cst_lower = CST[(2 * i + 1) * args.n_cst_coeffs]
                self.add_constraint(
                    f"thickness_val_{indexI}",
                    lower=args.le_radius_constraint * (cst_upper - cst_lower),
                    scaler=1.0,
                    linear=True,
                )
        # LE C1 continuous
        for i in range(n_sections):
            self.add_constraint(f"le_c1_val_{i}", equals=0.0, scaler=1.0, linear=True)


# OpenMDAO setup
prob = om.Problem()
prob.model = Top()
prob.setup(mode="rev")

# initialize the optimization function
optFuncs = OptFuncs(daOptions, prob)

# use pyoptsparse to setup optimization
prob.driver = om.pyOptSparseDriver()
prob.driver.options["optimizer"] = args.optimizer
# options for optimizers
if args.optimizer == "SNOPT":
    prob.driver.opt_settings = {
        "Major feasibility tolerance": 1.0e-4,
        "Major optimality tolerance": 1.0e-4,
        "Minor feasibility tolerance": 1.0e-4,
        "Verify level": -1,
        "Function precision": 1.0e-5,
        "Major iterations limit": args.max_opt_iters,
        "Nonderivative linesearch": None,
        "Print file": "opt_SNOPT_print.txt",
        "Summary file": "opt_SNOPT_summary.txt",
    }
elif args.optimizer == "IPOPT":
    prob.driver.opt_settings = {
        "tol": 1.0e-4,
        "constr_viol_tol": 1.0e-4,
        "max_iter": args.max_opt_iters,
        "print_level": 5,
        "output_file": "opt_IPOPT.txt",
        "mu_strategy": "adaptive",
        "limited_memory_max_history": 10,
        "nlp_scaling_method": "none",
        "alpha_for_y": "full",
        "recalc_y": "yes",
        "bound_frac": 1e-3,  # allow IPOPT to use init dv closer to upper bound
    }
elif args.optimizer == "SLSQP":
    prob.driver.opt_settings = {
        "ACC": 1.0e-4,
        "MAXIT": args.max_opt_iters,
        "IFILE": "opt_SLSQP.txt",
    }
else:
    print("optimizer arg not valid!")
    exit(1)

prob.driver.options["debug_print"] = ["nl_cons", "objs", "desvars"]
prob.driver.options["print_opt_prob"] = True
prob.driver.hist_file = "OptView.hst"

if args.task == "run_driver":
    # solve CL
    optFuncs.findFeasibleDesign(
        ["scenario1.aero_post.CL"],
        ["patchV"],
        targets=[args.lift_constraint],
        designVarsComp=[1],
        epsFD=[1e-2],
        tol=1e-3,
        maxIter=5,
    )
    # run the optimization
    prob.run_driver()
    if MPI.COMM_WORLD.rank == 0:
        os.system("touch .dafoam_run_finished")
elif args.task == "run_model":
    # just run the primal once
    prob.run_model()
    if MPI.COMM_WORLD.rank == 0:
        os.system("touch .dafoam_run_finished")
elif args.task == "compute_totals":
    # just run the primal and adjoint once
    prob.run_model()
    totals = prob.compute_totals()
    if MPI.COMM_WORLD.rank == 0:
        print(totals)
elif args.task == "check_totals":
    # verify the total derivatives against the finite-difference
    prob.run_model()
    prob.check_totals(compact_print=False, step=1e-3, form="central", step_calc="abs")
else:
    print("task arg not found!")
    exit(1)
