#!/usr/bin/env python

import argparse
import json
import os

from mdo_agent_wing import WingGenerateCFDMesh
from mdo_agent_wing import WingGenerateFEAMesh
from mdo_agent_wing import WingRunAeroOptimization
from mdo_agent_wing import WingRunAeroStructOptimization
from mdo_agent_wing import WingRunAeroStructSimulation
from mdo_agent_wing import WingRunAeroSimulation
from mdo_agent_base import copy_solver_files
from mdo_agent_base import convert_vsp3_to_cst
from mdo_agent_base import export_optimization_boundary_vtks
from mdo_agent_base import resolve_section_cst_coeffs


def main():
    parser = argparse.ArgumentParser(
        description="Workflow helper commands for wing skill prepare/analyze phases."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    copy_parser = subparsers.add_parser("copy-solver-files")
    copy_parser.add_argument("--solver-name", required=True)

    prep_parser = subparsers.add_parser("prepare-wing-case")
    prep_parser.add_argument("--airfoil-profiles", nargs="+", required=True)
    prep_parser.add_argument("--n-cst-coeffs", required=True, type=int)
    prep_parser.add_argument("--solver-name", required=True)
    prep_parser.add_argument("--case-dir", default=".")
    prep_parser.add_argument("--cst-coeffs", nargs="+", type=float, default=None)

    mesh_parser = subparsers.add_parser("write-mesh-analysis")
    mesh_parser.add_argument("--log-file", required=True)
    mesh_parser.add_argument("--metrics-file", required=True)
    mesh_parser.add_argument("--analysis-file", required=True)

    fea_parser = subparsers.add_parser("write-fea-mesh-analysis")
    fea_parser.add_argument("--analysis-file", required=True)

    cfd_parser = subparsers.add_parser("write-cfd-analysis")
    cfd_parser.add_argument("--log-file", required=True)
    cfd_parser.add_argument("--output-file", required=True)

    aero_struct_parser = subparsers.add_parser("write-aero-struct-analysis")
    aero_struct_parser.add_argument("--log-file", required=True)
    aero_struct_parser.add_argument("--output-file", required=True)
    aero_struct_parser.add_argument("--script-file", default="script_run_dafoam_aero_struct.py")
    aero_struct_parser.add_argument("--nlbgs-rel-tol", type=float, default=None)
    aero_struct_parser.add_argument("--nlbgs-abs-tol", type=float, default=None)

    aero_struct_opt_parser = subparsers.add_parser("write-aero-struct-optimization-analysis")
    aero_struct_opt_parser.add_argument("--log-file", required=True)
    aero_struct_opt_parser.add_argument("--output-file", required=True)

    opt_parser = subparsers.add_parser("write-optimization-analysis")
    opt_parser.add_argument("--log-file", required=True)
    opt_parser.add_argument("--output-file", required=True)

    export_opt_vtk_parser = subparsers.add_parser("export-optimization-boundary-vtks")
    export_opt_vtk_parser.add_argument("--case-dir", default=".")

    args = parser.parse_args()

    if args.command == "copy-solver-files":
        copy_solver_files(".", args.solver_name)
        return
    if args.command == "prepare-wing-case":
        cst_coeffs = args.cst_coeffs
        if cst_coeffs is None:
            cst_coeffs = resolve_section_cst_coeffs(
                args.airfoil_profiles,
                int(args.n_cst_coeffs),
                args.case_dir,
            )
        convert_vsp3_to_cst(
            args.case_dir,
            int(args.n_cst_coeffs),
            "wing.vsp3",
            "Wing",
            xsec_indices=range(len(args.airfoil_profiles)),
        )
        copy_solver_files(args.case_dir, args.solver_name)
        with open("cst_coeffs.prepare.json", "w", encoding="utf-8") as handle:
            json.dump(
                {"cst_coeffs": [float(value) for value in cst_coeffs]},
                handle,
                indent=2,
                sort_keys=True,
            )
        return
    if args.command == "export-optimization-boundary-vtks":
        export_optimization_boundary_vtks(
            case_dir=args.case_dir,
            patches="(wing sym)",
            fields="(U p T rho nut)",
        )
        return

    if args.command == "write-mesh-analysis":
        skill = WingGenerateCFDMesh()
        metrics = skill.parse_mesh_log(args.log_file)
        with open(args.metrics_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(metrics, handle, indent=2, sort_keys=True)

        analysis = {
            "outputs": [],
            "plots": [],
        }
        for filename in [
            "constant/polyMesh",
            "VTK/boundary.vtp",
        ]:
            if os.path.exists(filename):
                analysis["outputs"].append(filename)
        if os.path.isdir("plots"):
            case_name = os.path.basename(os.getcwd())
            for plot_name in sorted(os.listdir("plots")):
                if plot_name.lower().endswith(".png"):
                    analysis["plots"].append(os.path.join(case_name, "plots", plot_name))
        with open(args.analysis_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(analysis, handle, indent=2, sort_keys=True)
        return

    if args.command == "write-fea-mesh-analysis":
        analysis = {
            "outputs": [],
            "plots": [],
        }
        for filename in ["wingbox.bdf", "wingbox.dat"]:
            if os.path.exists(filename):
                analysis["outputs"].append(filename)
        if os.path.isdir("plots"):
            case_name = os.path.basename(os.getcwd())
            for plot_name in sorted(os.listdir("plots")):
                if plot_name.lower().endswith(".png"):
                    analysis["plots"].append(os.path.join(case_name, "plots", plot_name))
        with open(args.analysis_file, "w", encoding="utf-8", errors="ignore") as handle:
            json.dump(analysis, handle, indent=2, sort_keys=True)
        return

    if args.command == "write-cfd-analysis":
        skill = WingRunAeroSimulation()
        metrics = skill.build_convergence_metrics(skill.parse_simulation_log(args.log_file))
    elif args.command == "write-aero-struct-analysis":
        skill = WingRunAeroStructSimulation()
        metrics = skill.build_aero_struct_metrics(
            skill.parse_aero_struct_log(args.log_file),
            script_file=args.script_file,
            nlbgs_rel_tol=args.nlbgs_rel_tol,
            nlbgs_abs_tol=args.nlbgs_abs_tol,
        )
    elif args.command == "write-aero-struct-optimization-analysis":
        skill = WingRunAeroStructOptimization()
        metrics = skill.parse_optimization_log(args.log_file)
    else:
        skill = WingRunAeroOptimization()
        metrics = skill.parse_optimization_log(args.log_file)

    with open(args.output_file, "w", encoding="utf-8", errors="ignore") as handle:
        json.dump(metrics, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
