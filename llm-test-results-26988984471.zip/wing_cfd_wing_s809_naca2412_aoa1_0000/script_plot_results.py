#!/usr/bin/env python

import argparse
import subprocess

from mdo_agent_plot import (
    general_plot_function,
    general_plot_optimization_history,
    general_plot_residual,
    general_trame_view,
    wing_plot_flow_field,
    wing_plot_mesh,
    wing_plot_pressure_profile,
    wing_plot_wingbox_mesh,
)


def parse_args():
    parser = argparse.ArgumentParser(description="Thin mdo_agent_plot wrapper for case-local wing plotting.")
    parser.add_argument("-mode", type=str, required=True)
    parser.add_argument("-input_files", type=str, nargs="+", default=None)
    parser.add_argument("-port", type=int, default=8002)
    parser.add_argument("-case_dir", type=str, default=".")
    parser.add_argument("-camera_scale", type=float, default=0.9)
    parser.add_argument("-image_width", type=int, default=1920)
    parser.add_argument("-image_height", type=int, default=1150)
    parser.add_argument("-flow_field", type=str, default="p")
    parser.add_argument("-log_file", type=str, default="log_simulation.txt")
    parser.add_argument("-hist_file", type=str, default="OptView.hst")
    parser.add_argument("-optimizer_log", type=str, default="opt_IPOPT.txt")
    parser.add_argument("-start_time", type=int, default=0)
    parser.add_argument("-end_time", type=int, default=-1)
    parser.add_argument("-start_time_cfd", type=int, default=0)
    parser.add_argument("-end_time_cfd", type=int, default=-1)
    parser.add_argument("-start_time_adjoint", type=int, default=0)
    parser.add_argument("-end_time_adjoint", type=int, default=-1)
    parser.add_argument("-time_step", type=int, default=-1)
    parser.add_argument("-wing_span", type=float, default=1.0)
    parser.add_argument("-spanwise_chords", type=float, nargs="+", default=[1.0, 1.0, 1.0])
    parser.add_argument("-spanwise_x", type=float, nargs="+", default=[0.0, 0.0, 0.0])
    parser.add_argument("-spanwise_fractions", type=float, nargs="+", default=None)
    parser.add_argument("-mesh_file", type=str, nargs="+", default=["VTK/boundary.vtp"])
    parser.add_argument("-reference_pressure", type=float, default=None)
    parser.add_argument("-pressure_coefficient_scale", type=float, default=None)
    parser.add_argument("-geometry_file", type=str, default="wing.stl")
    return parser.parse_args()


def _run_shell(command, case_dir):
    completed = subprocess.run(["bash", "-lc", command], cwd=case_dir, text=True, capture_output=True)
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or completed.stdout.strip() or command)


def main():
    args = parse_args()
    mesh_files = args.mesh_file

    if args.mode == "wing_plot_mesh":
        return wing_plot_mesh(
            case_dir=args.case_dir,
            mesh_file=mesh_files[0],
            geometry_file=args.geometry_file,
            camera_scale=args.camera_scale,
            image_width=args.image_width,
            image_height=args.image_height,
        )
    if args.mode == "general_plot_residual":
        return general_plot_residual(
            case_dir=args.case_dir,
            log_file=args.log_file,
            start_time_cfd=args.start_time_cfd,
            end_time_cfd=args.end_time_cfd,
            start_time_adjoint=args.start_time_adjoint,
            end_time_adjoint=args.end_time_adjoint,
        )
    if args.mode == "general_plot_function":
        return general_plot_function(
            case_dir=args.case_dir,
            log_file=args.log_file,
            start_time=args.start_time,
            end_time=args.end_time,
        )
    if args.mode == "general_plot_optimization_history":
        return general_plot_optimization_history(
            case_dir=args.case_dir,
            hist_file=args.hist_file,
            optimizer_log=args.optimizer_log,
        )
    if args.mode == "wing_plot_flow_field":
        return wing_plot_flow_field(
            case_dir=args.case_dir,
            flow_field=args.flow_field,
            time_step=args.time_step,
            camera_scale=args.camera_scale,
            image_width=args.image_width,
            image_height=args.image_height,
            surface_file=mesh_files,
            geometry_file=args.geometry_file,
        )
    if args.mode == "wing_plot_pressure_profile":
        return wing_plot_pressure_profile(
            case_dir=args.case_dir,
            time_step=args.time_step,
            wing_span=args.wing_span,
            mesh_file=mesh_files,
            reference_pressure=args.reference_pressure,
            pressure_coefficient_scale=args.pressure_coefficient_scale,
            spanwise_chords=args.spanwise_chords,
            spanwise_x=args.spanwise_x,
            spanwise_fractions=args.spanwise_fractions,
        )
    if args.mode == "wing_plot_wingbox_mesh":
        return wing_plot_wingbox_mesh(
            case_dir=args.case_dir,
            camera_scale=args.camera_scale,
            image_width=args.image_width,
            image_height=args.image_height,
        )
    if args.mode == "trame_view":
        return general_trame_view(
            input_files=args.input_files,
            port=args.port,
        )

    raise ValueError(
        "Unsupported mode. Expected one of: "
        "wing_plot_mesh, wing_plot_wingbox_mesh, general_plot_residual, general_plot_function, "
        "general_plot_optimization_history, "
        "wing_plot_flow_field, wing_plot_pressure_profile, trame_view."
    )


if __name__ == "__main__":
    main()
