#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
mpirun -np 1 python script_run_dafoam.py -task=run_model -angle_of_attack=1.0 -mach_number=0.2 -solver_name=DARhoSimpleFoam -max_flow_iters=10000 -reynolds_number=5000000.0 -primal_func_std_tol=0.005 -primal_func_slope_tol=1e-06 -reference_area=2.25 -reference_length=0.75 -n_cst_coeffs=6 -cst_coeffs 0.15530798605730958 0.2526855692055664 0.3843990908268693 0.13416372100040783 0.314315506004613 0.15155388857061053 -0.15530798605730958 -0.15510738734844323 -0.5768068069386292 -0.07114818385595342 -0.2052242479030026 0.06236265987672021 0.1573247826584073 0.350899460919556 -0.09784458954277114 0.5859475190827591 -0.08781262405593299 0.35266936946501215 -0.1573247826584073 -0.1527470959615068 0.09205890729788879 -0.3975617850025036 0.19168962724126098 -0.21469343954270725 -chords 1 0.5 -spans 3 -sweeps 10 -dihedrals 0.0 -twists 2 > log_simulation.txt 2>&1
reconstructPar -withZero >> log_simulation.txt 2>&1
rm -rf processor* >> log_simulation.txt 2>&1
rm -rf VTK >> log_simulation.txt 2>&1
foamToVTK -latestTime -patches '(wing sym)' -fields '(U p T rho nut)' -one-boundary >> log_simulation.txt 2>&1
mv VTK/*/boundary.vtp VTK/ >> log_simulation.txt 2>&1 || true
touch run_finished.pid
