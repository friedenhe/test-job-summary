#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
python script_plot_results.py -mode general_plot_residual -case_dir . -log_file log_simulation.txt >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode general_plot_function -case_dir . -log_file log_simulation.txt >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode wing_plot_flow_field -case_dir . -flow_field p >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode wing_plot_flow_field -case_dir . -flow_field U >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode wing_plot_pressure_profile -case_dir . -time_step=-1 -mesh_file VTK/boundary.vtp -reference_pressure 101325.0 -pressure_coefficient_scale 2837.100000000001 -wing_span=3.0 -spanwise_chords 0.95 0.75 0.55 -spanwise_x 0.0528980942125395 0.26449047106269746 0.47608284791285543 -spanwise_fractions 0.1 0.5 0.9 >> log_plot_cfd.txt 2>&1
python script_workflow_helpers.py write-cfd-analysis --log-file log_simulation.txt --output-file cfd_analysis_metrics.json
