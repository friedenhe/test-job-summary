#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
python script_workflow_helpers.py prepare-wing-case --airfoil-profiles s809 naca2412 --n-cst-coeffs 6 --solver-name DARhoSimpleFoam --case-dir .
