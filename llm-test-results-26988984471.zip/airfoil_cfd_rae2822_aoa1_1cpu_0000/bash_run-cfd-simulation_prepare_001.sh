#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
python script_workflow_helpers.py prepare-airfoil-case --airfoil-profile rae2822 --n-cst-coeffs 6 --solver-name DARhoSimpleFoam --case-dir .
