#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
./Allclean.sh > log_mesh.txt 2>&1
python script_generate_mesh.py -airfoil_profile=rae2822 -mesh_cells=3000 -blunt_te=0.01 -y_plus=200.0 -mach_number=0.3 -reynolds_number=5000000.0 -d0=-1.0 >> log_mesh.txt 2>&1
createPatch -overwrite >> log_mesh.txt 2>&1
renumberMesh -overwrite >> log_mesh.txt 2>&1
rm -rf VTK >> log_mesh.txt 2>&1
foamToVTK -latestTime -patches '(wing symmetry1 symmetry2)' -one-boundary >> log_mesh.txt 2>&1
mv VTK/*/boundary.vtp VTK/ >> log_mesh.txt 2>&1 || true
touch run_finished.pid
