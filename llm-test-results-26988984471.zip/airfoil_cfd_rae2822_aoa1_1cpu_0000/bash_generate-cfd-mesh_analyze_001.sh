#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
checkMesh >> log_mesh.txt 2>&1 || exit 200
python script_workflow_helpers.py write-mesh-analysis --log-file log_mesh.txt --output-file mesh_analysis_metrics.json
python script_plot_results.py -mode airfoil_plot_mesh -case_dir . -plot_all_views 1 >> log_mesh.txt 2>&1
