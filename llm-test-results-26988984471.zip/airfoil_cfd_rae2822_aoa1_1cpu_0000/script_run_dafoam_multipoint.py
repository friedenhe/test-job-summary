#!/usr/bin/env python

# =============================================================================
# Imports
# =============================================================================
import os
import argparse
import numpy as np
from mpi4py import MPI
import openmdao.api as om
from mphys.multipoint import Multipoint
from dafoam.mphys import DAFoamBuilder, OptFuncs, DAFoamLinearConstraint, DAFoamVSPVolume
from mphys.scenario_aerodynamic import ScenarioAerodynamic
from pygeo.mphys import OM_DVGEOCOMP

parser = argparse.ArgumentParser()
parser.add_argument("-optimizer", help="optimizer to use", type=str, default="IPOPT")
parser.add_argument("-task", help="type of run to do", type=str, default="run_driver")
parser.add_argument(
    "-weights",
    help="Weight for each flight condition in the multipoint objective. Must sum to 1.0.",
    type=float,
    nargs="+",
    default=[0.5, 0.5],
)
parser.add_argument(
    "-angle_of_attack",
    help="Initial freestream angle of attack in degrees for each flight condition.",
    type=float,
    nargs="+",
    default=[5.0, 4.0],
)
parser.add_argument(
    "-lift_constraint",
    help="Target lift coefficient for each flight condition.",
    type=float,
    nargs="+",
    default=[0.5, 0.4],
)
parser.add_argument("-mach_number", help="freestream Mach number", type=float, default=0.2)
parser.add_argument(
    "-solver_name",
    help="Resolved solver name passed by the calling skill.",
    type=str,
    required=True,
)
parser.add_argument("-reynolds_number", help="Reynolds number", type=float, default=5e6)
parser.add_argument("-max_opt_iters", help="maximum number of optimization iterations", type=int, default=100)
parser.add_argument("-max_adj_iters", help="The max GMRES iterations for the adjoint solve", type=int, default=1000)
parser.add_argument("-pc_fill_level", help="The ILU fill level for the adjoint preconditioner", type=int, default=1)
parser.add_argument("-max_flow_iters", help="maximum number of flow solver iterations", type=int, default=3000)
parser.add_argument(
    "-cst_coeffs",
    help="Initial CST coefficients for the VSP geometry path, ordered as [upper..., lower...].",
    type=float,
    nargs="+",
    default=None,
)
parser.add_argument(
    "-thickness_constraint", help="Thickness constraint lower bound (-1 to disable)", type=float, default=0.5
)
parser.add_argument(
    "-le_radius_constraint", help="LE radius constraint lower bound (-1 to disable)", type=float, default=-1.0
)
args = parser.parse_args()
if args.cst_coeffs is None:
    raise ValueError("cst_coeffs must be provided for the VSP geometry path.")
if len(args.cst_coeffs) < 2 or len(args.cst_coeffs) % 2 != 0:
    raise ValueError(
        "cst_coeffs must contain an even number of CST coefficients "
        f"(upper surface followed by lower surface), got {len(args.cst_coeffs)}"
    )
n_cst_coeffs = len(args.cst_coeffs) // 2

# =============================================================================
# Input Parameters
# =============================================================================

# Clean up previous run results
if MPI.COMM_WORLD.rank == 0:
    os.system("rm -rf postProcessing")
    os.system("rm -rf processor* 0.00* ")
    os.system("rm -rf *.bin *.info *.jpeg *.png reports *.hst")
    os.system("rm -rf {1..9}*")
    os.system(f"sed -i 's/^endTime.*/endTime         {int(args.max_flow_iters)};/' system/controlDict")
    os.system(f"sed -i 's/^writeInterval.*/writeInterval   {int(args.max_flow_iters)};/' system/controlDict")

T0 = 300.0
nuTilda0 = 4.5e-5

L0 = 1.0
R = 287.0
k = 1.4
C = float(np.sqrt(k * R * T0))
U0 = args.mach_number * C

# Multipoint flight conditions: two AoA values and two weights, one Mach number shared between both.
weights = args.weights
aoa0 = args.angle_of_attack

# Reference area: chord (1.0 m) x span (0.01 m, matching the z-extruded mesh).
A0 = 0.01

# Use scenario 1's AoA for the shared primal initial condition.
Ux = float(U0 * np.cos(np.radians(aoa0[0])))
Uy = float(U0 * np.sin(np.radians(aoa0[0])))

solverName = args.solver_name
if solverName == "DASimpleFoam":
    transonicPC = 0
    p0 = 0.0
    rho0 = 1.0
    p_norm = U0 * U0 / 2.0
    IC = {"U": [Ux, Uy, 0.0], "p": p0}
elif solverName == "DARhoSimpleFoam":
    transonicPC = 0
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    IC = {"U": [Ux, Uy, 0.0], "p": p0, "T": T0}
elif solverName == "DARhoSimpleCFoam":
    transonicPC = 1
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    IC = {"U": [Ux, Uy, 0.0], "p": p0, "T": T0}
elif solverName == "DAHisaFoam":
    p0 = 101325.0
    rho0 = p0 / R / T0
    p_norm = p0
    transonicPC = 1
    IC = {"U": [Ux, Uy, 0.0], "p": p0, "T": T0}
else:
    raise ValueError(f"Unsupported solverName `{solverName}`")

nu = U0 * L0 / args.reynolds_number
mu = nu * rho0

if solverName == "DAHisaFoam":
    BC = {
        "charFarFieldBC": [Ux, Uy, 0.0, p0, T0],
        "thermo:mu": mu,
        "useWallFunction": False,
    }
elif solverName == "DASimpleFoam":
    BC = {
        "U0": {"variable": "U", "patches": ["inout"], "value": [Ux, Uy, 0.0]},
        "p0": {"variable": "p", "patches": ["inout"], "value": [p0]},
        "nuTilda0": {"variable": "nuTilda", "patches": ["inout"], "value": [nuTilda0]},
        "transport:nu": nu,
        "useWallFunction": True,
    }
else:
    BC = {
        "U0": {"variable": "U", "patches": ["inout"], "value": [Ux, Uy, 0.0]},
        "p0": {"variable": "p", "patches": ["inout"], "value": [p0]},
        "T0": {"variable": "T", "patches": ["inout"], "value": [T0]},
        "nuTilda0": {"variable": "nuTilda", "patches": ["inout"], "value": [nuTilda0]},
        "thermo:mu": mu,
        "useWallFunction": True,
    }

# Scaling factors convert raw force (scale=1.0 in daOptions) to a drag/lift coefficient.
# Both conditions share the same Mach number and reference area, so scalings are equal.
scalings = [
    1.0 / (0.5 * A0 * rho0 * U0 * U0),
    1.0 / (0.5 * A0 * rho0 * U0 * U0),
]
# Dimensional lift-force targets derived from the per-scenario coefficient targets.
lift_target = [
    args.lift_constraint[0] / scalings[0],
    args.lift_constraint[1] / scalings[1],
]

# Input parameters for DAFoam
daOptions = {
    "designSurfaces": ["wing"],
    "solverName": solverName,
    "transonicPCOption": transonicPC,
    "primalMinResTol": 1.0e-7,
    "primalMinResTolDiff": 1e3,
    "primalFuncStdTol": {"stdTol": 1e-5, "funcNames": ["drag"], "nStepsFrac": 0.2},
    "primalMinIters": 50,
    "printInterval": 10,
    "primalInitCondition": IC,
    "primalBC": BC,
    "function": {
        "drag": {
            "type": "force",
            "source": "patchToFace",
            "patches": ["wing"],
            "directionMode": "parallelToFlow",
            "patchVelocityInputName": "patchV",
            "scale": 1.0,
        },
        "lift": {
            "type": "force",
            "source": "patchToFace",
            "patches": ["wing"],
            "directionMode": "normalToFlow",
            "patchVelocityInputName": "patchV",
            "scale": 1.0,
        },
    },
    "adjStateOrdering": "cell",
    "adjEqnOption": {
        "gmresRelTol": 1.0e-5,
        "pcFillLevel": args.pc_fill_level,
        "jacMatReOrdering": "natural",
        "gmresMaxIters": args.max_adj_iters,
        "gmresRestart": args.max_adj_iters,
    },
    "normalizeStates": {
        "U": U0,
        "p": p_norm,
        "T": T0,
        "nuTilda": nuTilda0 * 10.0,
        "phi": 1.0,
    },
    "inputInfo": {
        "aero_vol_coords": {"type": "volCoord", "components": ["solver", "function"]},
        "patchV": {
            # The mesh is extruded 0.01 m in z; the 2D flow lies in the x-y plane, so lift
            # is in the y direction and normalAxis must be "y".
            "type": "patchVelocity",
            "patches": ["inout"],
            "flowAxis": "x",
            "normalAxis": "y",
            "components": ["solver", "function"],
        },
    },
    "checkMeshThreshold": {
        "maxNonOrth": 70.0,
        "maxSkewness": 6.0,
        "maxAspectRatio": 10000.0,
    },
}

# Mesh deformation setup.
# Symmetry planes are at z=0 and z=0.01, matching the 0.01 m z-extrusion of the generated mesh.
meshOptions = {
    "gridFile": os.getcwd(),
    "fileType": "OpenFOAM",
    "symmetryPlanes": [
        [[0.0, 0.0, 0.0], [0.0, 0.0, 1.0]],
        [[0.0, 0.0, 0.01], [0.0, 0.0, 1.0]],
    ],
}


# Top class to setup the multipoint optimization problem
class Top(Multipoint):
    def setup(self):

        # create the builder to initialize the DASolvers
        dafoam_builder = DAFoamBuilder(daOptions, meshOptions, scenario="aerodynamic")
        dafoam_builder.initialize(self.comm)

        # add the design variable component to keep the top level design variables
        self.add_subsystem("dvs", om.IndepVarComp(), promotes=["*"])

        # add the mesh component
        self.add_subsystem("mesh", dafoam_builder.get_mesh_coordinate_subsystem())

        # Use the case-local OpenVSP geometry for airfoil design updates via CST coefficients.
        self.add_subsystem("geometry", OM_DVGEOCOMP(file="airfoil.vsp3", type="vsp"))

        # Two scenarios for multipoint optimization — one per flight condition.
        self.mphys_add_scenario("scenario1", ScenarioAerodynamic(aero_builder=dafoam_builder))
        self.mphys_add_scenario("scenario2", ScenarioAerodynamic(aero_builder=dafoam_builder))

        # Connect the surface mesh from the mesh component to the VSP geometry component.
        self.connect("mesh.x_aero0", "geometry.x_aero_in")
        # Both scenarios share the same deformed geometry output.
        self.connect("geometry.x_aero0", "scenario1.x_aero")
        self.connect("geometry.x_aero0", "scenario2.x_aero")

        # Thickness and LE continuity constraints operate on the CST design variables directly.
        varA = []
        varB = []
        for j in range(n_cst_coeffs):
            varA.append(f"UpperCoeff_{j}")
            varB.append(f"LowerCoeff_{j}")
        self.add_subsystem(
            "thickness",
            DAFoamLinearConstraint(
                varA=varA, coeffA=1.0, varB=varB, coeffB=-1.0, size=1, output_name="thickness_val"
            ),
            promotes=["*"],
        )

        self.add_subsystem(
            "le_c1",
            DAFoamLinearConstraint(
                varA=["UpperCoeff_0"],
                coeffA=1.0,
                varB=["LowerCoeff_0"],
                coeffB=1.0,
                size=1,
                output_name="le_c1_val",
            ),
            promotes=["*"],
        )

        vsp_vars = []
        for i in range(2):
            for j in range(n_cst_coeffs):
                vsp_vars.append(f"Airfoil:UpperCoeff_{i}:Au_{j}")
                vsp_vars.append(f"Airfoil:LowerCoeff_{i}:Al_{j}")
        self.add_subsystem(
            "volume",
            DAFoamVSPVolume(
                vsp_file="airfoil.vsp3",
                vsp_vars=vsp_vars,
                slice_dir="x",
                n_slices=10,
                output_name="volume_val",
                step=1e-6,
                relativeStep=False,
            ),
        )

        # Weighted multipoint objective: w1*drag1 + w2*drag2, where each drag is
        # a raw force and the weight already incorporates the coefficient scaling.
        self.add_subsystem(
            "obj",
            om.ExecComp(
                "val=w1*drag1+w2*drag2",
                w1={"val": weights[0] * scalings[0], "constant": True},
                w2={"val": weights[1] * scalings[1], "constant": True},
            ),
        )

    def configure(self):

        # get the surface coordinates from the mesh component
        points = self.mesh.mphys_get_surface_mesh()

        # add pointset to the geometry component
        self.geometry.nom_add_discipline_coords("aero", points)

        # set the triangular points to the geometry component for geometric constraints
        tri_points = self.mesh.mphys_get_triangulated_surface()
        self.geometry.nom_setConstraintSurface(tri_points)

        # Register the CST coefficients on both airfoil sections so one DV updates the whole 2D extrusion.
        for i in range(2):
            for j in range(n_cst_coeffs):
                self.geometry.nom_addVSPVariable("Airfoil", f"UpperCoeff_{i}", f"Au_{j}", scaledStep=False, dh=1e-6)
                self.geometry.nom_addVSPVariable("Airfoil", f"LowerCoeff_{i}", f"Al_{j}", scaledStep=False, dh=1e-6)

        for j in range(n_cst_coeffs):
            self.dvs.add_output(f"UpperCoeff_{j}", val=args.cst_coeffs[j])
            self.connect(f"UpperCoeff_{j}", f"geometry.Airfoil:UpperCoeff_0:Au_{j}")
            self.connect(f"UpperCoeff_{j}", f"geometry.Airfoil:UpperCoeff_1:Au_{j}")
            self.connect(f"UpperCoeff_{j}", f"volume.Airfoil:UpperCoeff_0:Au_{j}")
            self.connect(f"UpperCoeff_{j}", f"volume.Airfoil:UpperCoeff_1:Au_{j}")

            self.dvs.add_output(f"LowerCoeff_{j}", val=args.cst_coeffs[j + n_cst_coeffs])
            self.connect(f"LowerCoeff_{j}", f"geometry.Airfoil:LowerCoeff_0:Al_{j}")
            self.connect(f"LowerCoeff_{j}", f"geometry.Airfoil:LowerCoeff_1:Al_{j}")
            self.connect(f"LowerCoeff_{j}", f"volume.Airfoil:LowerCoeff_0:Al_{j}")
            self.connect(f"LowerCoeff_{j}", f"volume.Airfoil:LowerCoeff_1:Al_{j}")

        for j in range(n_cst_coeffs):
            self.add_design_var(f"UpperCoeff_{j}", lower=-1.0, upper=1.0, scaler=10.0)
            self.add_design_var(f"LowerCoeff_{j}", lower=-1.0, upper=1.0, scaler=10.0)

        # Each flight condition has its own patchV DV: [speed_magnitude, angle_of_attack_degrees].
        # Speed is fixed (lower == upper == U0); only the AoA component is optimized.
        self.dvs.add_output("patchV1", val=np.array([U0, aoa0[0]]))
        self.dvs.add_output("patchV2", val=np.array([U0, aoa0[1]]))
        self.connect("patchV1", "scenario1.patchV")
        self.connect("patchV2", "scenario2.patchV")
        self.add_design_var("patchV1", lower=[U0, 0.0], upper=[U0, 10.0], scaler=0.1)
        self.add_design_var("patchV2", lower=[U0, 0.0], upper=[U0, 10.0], scaler=0.1)

        # Per-scenario lift constraints using the dimensional force targets derived from
        # the coefficient inputs and the shared reference dynamic pressure.
        self.add_constraint("scenario1.aero_post.lift", equals=lift_target[0], scaler=1.0)
        self.add_constraint("scenario2.aero_post.lift", equals=lift_target[1], scaler=1.0)
        self.add_constraint("volume.volume_val", lower=1.0, scaler=1.0)

        if args.thickness_constraint >= 0:
            for j in range(1, n_cst_coeffs):
                lb = args.thickness_constraint * (args.cst_coeffs[j] - args.cst_coeffs[n_cst_coeffs + j])
                self.add_constraint(f"thickness_val_{j}", lower=lb, scaler=1.0, linear=True)
        if args.le_radius_constraint >= 0:
            lb = args.le_radius_constraint * (args.cst_coeffs[0] - args.cst_coeffs[n_cst_coeffs])
            self.add_constraint("thickness_val_0", lower=lb, scaler=1.0, linear=True)
        self.add_constraint("le_c1_val_0", equals=0.0, scaler=1.0, linear=True)

        # Weighted multipoint drag objective connecting both scenario outputs.
        self.add_objective("obj.val", scaler=10.0)
        self.connect("scenario1.aero_post.drag", "obj.drag1")
        self.connect("scenario2.aero_post.drag", "obj.drag2")


# OpenMDAO setup
prob = om.Problem()
prob.model = Top()
prob.setup(mode="rev")

# initialize the optimization function
optFuncs = OptFuncs(daOptions, prob)

# use pyoptsparse to setup optimization
prob.driver = om.pyOptSparseDriver()
prob.driver.options["optimizer"] = args.optimizer
# options for optimizers
if args.optimizer == "SNOPT":
    prob.driver.opt_settings = {
        "Major feasibility tolerance": 1.0e-4,
        "Major optimality tolerance": 1.0e-4,
        "Minor feasibility tolerance": 1.0e-4,
        "Verify level": -1,
        "Function precision": 1.0e-5,
        "Major iterations limit": args.max_opt_iters,
        "Nonderivative linesearch": None,
        "Print file": "opt_SNOPT_print.txt",
        "Summary file": "opt_SNOPT_summary.txt",
    }
elif args.optimizer == "IPOPT":
    prob.driver.opt_settings = {
        "tol": 1.0e-4,
        "constr_viol_tol": 1.0e-4,
        "max_iter": args.max_opt_iters,
        "print_level": 5,
        "output_file": "opt_IPOPT.txt",
        "mu_strategy": "adaptive",
        "limited_memory_max_history": 10,
        "nlp_scaling_method": "none",
        "alpha_for_y": "full",
        "recalc_y": "yes",
        "bound_frac": 1e-3,
    }
elif args.optimizer == "SLSQP":
    prob.driver.opt_settings = {
        "ACC": 1.0e-4,
        "MAXIT": args.max_opt_iters,
        "IFILE": "opt_SLSQP.txt",
    }
else:
    print("optimizer arg not valid!")
    exit(1)

prob.driver.options["debug_print"] = ["nl_cons", "objs", "desvars"]
prob.driver.options["print_opt_prob"] = True
prob.driver.hist_file = "OptView.hst"

if args.task == "run_driver":
    # Solve for feasible lift at both flight conditions before starting the optimizer.
    optFuncs.findFeasibleDesign(
        ["scenario1.aero_post.lift", "scenario2.aero_post.lift"],
        ["patchV1", "patchV2"],
        designVarsComp=[1, 1],
        targets=lift_target,
    )
    # run the optimization
    prob.run_driver()
elif args.task == "run_model":
    # just run the primal once
    prob.run_model()
elif args.task == "compute_totals":
    # just run the primal and adjoint once
    prob.run_model()
    totals = prob.compute_totals()
    if MPI.COMM_WORLD.rank == 0:
        print(totals)
elif args.task == "check_totals":
    # verify the total derivatives against the finite-difference
    prob.run_model()
    prob.check_totals(compact_print=False, step=1e-3, form="central", step_calc="abs")
else:
    print("task arg not found!")
    exit(1)
