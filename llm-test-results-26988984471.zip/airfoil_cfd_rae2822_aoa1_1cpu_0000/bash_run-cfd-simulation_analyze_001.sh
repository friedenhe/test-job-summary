#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
python script_plot_results.py -mode general_plot_residual -case_dir . -log_file log_simulation.txt >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode general_plot_function -case_dir . -log_file log_simulation.txt >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode airfoil_plot_flow_field -case_dir . -flow_field p -time_step -1 >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode airfoil_plot_flow_field -case_dir . -flow_field U -time_step -1 >> log_plot_cfd.txt 2>&1
python script_plot_results.py -mode airfoil_plot_pressure_profile -case_dir . -mesh_file VTK/boundary.vtp -reference_pressure 101325.0 -pressure_coefficient_scale 6383.4749999999985 -time_step -1 >> log_plot_cfd.txt 2>&1
python script_workflow_helpers.py write-cfd-analysis --log-file log_simulation.txt --output-file cfd_analysis_metrics.json
