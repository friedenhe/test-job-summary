#!/usr/bin/env python

import argparse
import json

from mdo_agent_airfoil import AirfoilGenerateCFDMesh
from mdo_agent_airfoil import AirfoilRunAeroOptimization
from mdo_agent_airfoil import AirfoilRunCFDSimulation
from mdo_agent_base import copy_solver_files
from mdo_agent_base import convert_vsp3_to_cst
from mdo_agent_base import export_optimization_boundary_vtks
from mdo_agent_base import fit_airfoil_cst


def main():
    parser = argparse.ArgumentParser(
        description="Workflow helper commands for airfoil skill prepare/analyze phases."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    copy_parser = subparsers.add_parser("copy-solver-files")
    copy_parser.add_argument("--solver-name", required=True)

    prep_parser = subparsers.add_parser("prepare-airfoil-case")
    prep_parser.add_argument("--airfoil-profile", required=True)
    prep_parser.add_argument("--n-cst-coeffs", required=True, type=int)
    prep_parser.add_argument("--solver-name", required=True)
    prep_parser.add_argument("--case-dir", default=".")
    prep_parser.add_argument("--cst-coeffs", nargs="+", type=float, default=None)

    mesh_parser = subparsers.add_parser("write-mesh-analysis")
    mesh_parser.add_argument("--log-file", required=True)
    mesh_parser.add_argument("--output-file", required=True)

    cfd_parser = subparsers.add_parser("write-cfd-analysis")
    cfd_parser.add_argument("--log-file", required=True)
    cfd_parser.add_argument("--output-file", required=True)

    opt_parser = subparsers.add_parser("write-optimization-analysis")
    opt_parser.add_argument("--log-file", required=True)
    opt_parser.add_argument("--output-file", required=True)

    export_opt_vtk_parser = subparsers.add_parser("export-optimization-boundary-vtks")
    export_opt_vtk_parser.add_argument("--case-dir", default=".")

    args = parser.parse_args()

    if args.command == "copy-solver-files":
        copy_solver_files(".", args.solver_name)
        return
    if args.command == "prepare-airfoil-case":
        cst_coeffs = args.cst_coeffs
        if cst_coeffs is None:
            coeffs = fit_airfoil_cst(
                str(args.airfoil_profile).strip().lower(),
                int(args.n_cst_coeffs),
                profiles_dir="profiles",
            )
            cst_coeffs = list(coeffs["upper"]) + list(coeffs["lower"])
        convert_vsp3_to_cst(
            args.case_dir,
            int(args.n_cst_coeffs),
            "airfoil.vsp3",
            "Airfoil",
            xsec_indices=(0, 1),
        )
        copy_solver_files(args.case_dir, args.solver_name)
        with open("cst_coeffs.prepare.json", "w", encoding="utf-8") as handle:
            json.dump(
                {"cst_coeffs": [float(value) for value in cst_coeffs]},
                handle,
                indent=2,
                sort_keys=True,
            )
        return
    if args.command == "export-optimization-boundary-vtks":
        export_optimization_boundary_vtks(
            case_dir=args.case_dir,
            patches="(wing symmetry1 symmetry2)",
            fields="(U p T rho nut)",
        )
        return

    if args.command == "write-mesh-analysis":
        skill = AirfoilGenerateCFDMesh()
        metrics = skill.parse_mesh_log(args.log_file)
    elif args.command == "write-cfd-analysis":
        skill = AirfoilRunCFDSimulation()
        metrics = skill.build_convergence_metrics(skill.parse_simulation_log(args.log_file))
    else:
        skill = AirfoilRunAeroOptimization()
        metrics = skill.parse_optimization_log(args.log_file)

    with open(args.output_file, "w", encoding="utf-8", errors="ignore") as handle:
        json.dump(metrics, handle, indent=2, sort_keys=True)


if __name__ == "__main__":
    main()
