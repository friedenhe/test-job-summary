#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
mpirun -np 1 python script_run_dafoam.py -task=run_model -angle_of_attack=1 -mach_number=0.3 -solver_name=DARhoSimpleFoam -max_flow_iters=10000 -reynolds_number=5000000.0 -primal_func_std_tol=0.005 -primal_func_slope_tol=1e-06  -cst_coeffs 0.12639203967511298 0.14212361493516132 0.15338011358057074 0.21740826327761234 0.17228999324201263 0.21270558788513022 -0.12639203967511298 -0.13254429647378493 -0.2027546988883599 -0.13908195391613196 -0.07914921566463665 0.05206900604396697 > log_simulation.txt 2>&1
reconstructPar -withZero >> log_simulation.txt 2>&1
rm -rf processor* >> log_simulation.txt 2>&1
rm -rf VTK >> log_simulation.txt 2>&1
foamToVTK -latestTime -patches '(wing symmetry1 symmetry2)' -fields '(U p T rho nut)' -one-boundary >> log_simulation.txt 2>&1
mv VTK/*/boundary.vtp VTK/ >> log_simulation.txt 2>&1 || true
touch run_finished.pid
