#!/bin/bash
. /home/dafoamuser/dafoam/loadDAFoam.sh
python script_prepare_airfoil.py --mode normalize --profile-file profiles/rae2822.dat --target-points 200
